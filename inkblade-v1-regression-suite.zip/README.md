# Inkblade v1 regression suite
Real dispatched pointer events via puppeteer (direct handler invocation is banned).
Setup: `npm install puppeteer` (Node 18+), place suite next to the game HTML files.
File paths inside scripts point at /home/claude/inkblade/ — adjust to your layout.

| Suite | Targets | Covers |
|---|---|---|
| smoke.js | inkblade-m0.html | start, 一 lock, wrong-order fizzle, deflect, whiff, bucket classification |
| smoke2.js | inkblade-m0.html | full 8-char roster locked in canonical order; 木 crossing-stroke stress |
| smoke3.js | inkblade-m05.html (rerun vs m075: sed the filename) | all composites lock, hint ladder (idle→breathe, flail→comet), 森 component-order fizzle + break classification, singles regression |
| smoke4.js | inkblade-m075.html | world planting, per-instance variance, relock metric, persistence across reload, horizon uniqueness, 森=3 trees, fizzle plants nothing |

All suites must pass with zero console errors on every build. Extend, never delete.
